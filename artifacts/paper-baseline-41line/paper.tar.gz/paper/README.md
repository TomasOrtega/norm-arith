# Norm arithmetic paper

This is a four-page workshop-style research draft with references and technical
appendices. It uses the unchanged official NeurIPS 2026 style in preprint mode,
with anonymous draft author information. It does not assert submission or
acceptance at a workshop.

The released PDF reports the frozen 41-line experiment and its measured 1.105×
warm affected-file speedup. The later [expansion report](../benchmarks/expansion/RESULTS.md)
records 232 net lines saved with the extended tactic. That patch is source-verified
and untimed; its implementation and results are not included in this PDF.

From the repository root:

```sh
python3 paper/build.py --reuse-checked-examples --render
```

The release build uses the validated portable evidence bundle. It imports the
four saved Lean-checked examples, regenerates the tables, runs XeLaTeX and
BibTeX through latexmk, and checks the log and four-page main-body limit. This
mode launches no Lean or native build. Review every rendered PNG under
`paper/tmp/pdfs/` before delivery. The result is `paper/output/pdf/paper.pdf`.

The ordinary build mode without `--reuse-checked-examples` builds `NormArith`
and freshly compiles the example module. Use a separate live checkout for that
replay; it is not needed to reproduce the released PDF or timing analysis.

During integration, `python3 paper/build.py --draft --render` permits missing
example snippets. It visibly labels unfinished evidence and does not establish
a checked-example result. A release build must succeed without `--draft`.

Snippet markers are `-- paper:begin hidden` and `-- paper:end hidden`, with the
names `hidden`, `reverse`, `mathlib`, and `boundary`. Include each example's
statement and proof between the markers. Shared section variables may remain
outside the displayed block; the entire module is compiled.

`generate.py` reads `benchmarks/results/report.json` and the archived candidate
manifest. It verifies the original mathlib block against its pinned hash.
These are pilot results: five replacements, 39 fewer proof lines, 36 after new
imports, and slower compilation. The broader semantic census and confirmatory
speed result are separate inputs in `status.json`; absent data stays explicitly
incomplete in the PDF. Generated provenance records the actual source hashes.

The tested numerical runtime is Python 3.15.0, as recorded in the timing
provenance. Exact bootstrap-distribution hashes depend on the numerical and
runtime conventions. Other Python versions have not been validated for
identical statistical hashes. To select that Python version explicitly, use
`uv run --python 3.15.0 python paper/build.py --render` in the live workspace,
or add `--reuse-checked-examples` for a validated portable bundle.

The local route is XeLaTeX with the Times-compatible TeX Gyre Termes, JuliaMono for Lean
code, `fontspec`, `fvextra`, `natbib`, and BibTeX under TeX Live 2026. It requires
`latexmk`, `kpsewhich`, `pdfinfo`, `pdffonts`, `pdftotext`, and `pdftoppm`. No shell escape is required.
Different TeX or font versions can change layout or PDF bytes; record the
environment when distributing the artifact.

The official style came from
<https://media.neurips.cc/Conferences/NeurIPS2026/Formatting_Instructions_For_NeurIPS_2026.zip>
(archive SHA-256
`82473931e3ef710fcd3f4a8cd4119b9de32e56825f90f9e5a6d55f2d01b817d9`).
The organizer format reference is <https://mathai-2026.github.io/cfp/>.

The STE review has a complete 53-rule applicability matrix in
`language-audit.md`, a project vocabulary/POS/sense ledger in
`vocabulary-review.tsv`, and a corpus-bound record in `language-review.json`.
It declares mathematical and research-format exceptions; it does not assert
unqualified ASD-STE100 conformance or external certification. After a prose
change, inspect every affected context and the complete language requirements,
then run `python3 paper/audit.py --record-review`. A release build rejects
unreviewed words, open length candidates, and a changed review snapshot.
The build generates status prose before this check, so new evidence also needs
review. The official dictionary is not bundled with this project.

## Final evidence inputs

`status.awaiting-data.json` is an empty template. The current `status.json`
binds the validated census archive and the selected, compiled frozen patch.
All four evidence stages are complete; the release uses their portable bundle. The main text reports the finished census
protocol with its extraction gaps; the archived negative pilot is separate in
the appendix. The adapter never uses a calibration run or the pilot as a
substitute for final evidence.

An earlier selected patch contains a line above mathlib's 100-character limit.
Formatting that line removes the affected file's net line saving. The final
paper configuration must therefore bind the revised selection, combined source
verification, frozen manifest, fresh calibration, and fresh confirmatory run.
Keep the earlier fixed timing study as a superseded record; its measurements
must not be used as the revised patch's result. Anticipated line counts do not
enter the generated evidence before validation.

Paths in `status.json` are relative to the repository root or absolute. Enable a
whole group at a time:

| Stage | Required paths |
| --- | --- |
| Full census | `census_summary`, `census_manifest`, `census_integrity` (from a validated compact archive) |
| Deterministic selection | `selector_summary`, `selector_manifest`, `selector_ledger` |
| Compiled frozen patch | `source_verification_report`, `frozen_manifest` |
| Confirmatory timing | `confirmatory_report`, `confirmatory_analysis_plan`, `confirmatory_measurements` |

`census_outcomes` can point to an archived `file-outcomes.jsonl`. Without it,
the adapter uses that file beside the manifest when present, or reads every
latest `files/<module>/result.json` in the original run. The final census paths must refer to the validated compact archive produced by
`scripts/archive_census.py`. `census_archive` can override its `archive.json`
path; the default is beside the census manifest. The adapter checks the archive
receipt, complete compact byte inventory, validation-tool hashes, and exact
agreement of its file outcomes and coverage with the census. The compact archive
must retain its `frozen-implementation` snapshots. `source_verified_manifest`
can override the verified trial manifest; its default is `manifest.json` beside
the source-verification report. The frozen manifest must preserve the verified
trial's content, except for its selection status and added freeze metadata.

The adapter checks the pinned checkout and exact tracked source inventory,
protocol and snapshot hashes, final integrity, all file outcomes and aggregate
counts. It accepts a finished full run with explicitly retained extraction
failures. It rejects an unprocessed file, a calibration subset, or a census that
still has pending integrity. Isolated proposals never supply compiled patch
savings. Selection accounting is recomputed from source; the combined patch,
selected IDs, compiler output hashes, verified trial, and frozen manifest must
match. The figure for proof savings charges preparation, helpers, and imports.
Tactic implementation code and census infrastructure code have separate costs;
no total-repository reduction follows from the proof figure.

For timing, the adapter checks the plan and its frozen inputs, all affected
files, warmups and measured samples, saved setup artifacts, runtime calibration,
and pilot references. It recomputes the ratio of mean full-pass totals and the
paired block BCa interval from raw JSONL. `claim_speedup` defaults to false.
Setting it to true requires the valid interval's lower endpoint to exceed one.
A complete negative timing result remains reportable with `claim_speedup=false`.
The generated appendix includes every affected file, including slower files,
and keeps native import attribution separate from algorithmic efficiency.

Known eligible observations without a terminal outcome are postprocessed as
`unknown_due_incomplete_file`. The adapter requires nonnegative integer counts
and a zero residual in every complete file; it rejects negative residuals rather
than clamping them. Logged attempt outcomes plus this residual partition known
eligible observations. A failed file can contain other goals extraction never
reached. Counters from final `file_end` records do not count all known observations.

Generated final tables and their input hashes are under `paper/generated/`.
Absent stages leave their tables empty. `study-facts.tex` gets all census and
patch figures from validated evidence. `example_candidate_id` selects one
entry from the compiled patch; the generator checks its source-span hash and
combined verification before importing the literal original and replacement.
The `census-example.json` record binds its ID, declaration, source lines, full
source hashes, protocol, patch, and compiler outputs. Enabling real data changes
prose and captions and needs a new full contextual language pass, strict build,
and visual review. The negative pilot remains separate in the appendix.

Run the lightweight adapter regressions with:

```sh
python3 -m unittest discover -s paper -p test_evidence.py
```

Their temporary files are explicitly synthetic. They do not compile Lean or
contribute manuscript observations, proof checks, line savings, or timings.

## Portable evidence bundle

After final live validation, export a curated release bundle:

```sh
python3 paper/evidence.py --status paper/status.json \
  --export artifacts/paper-evidence
```

The destination must be new. Export requires all four validated stages. It
writes into a temporary directory, checks the portable form, and then publishes
the directory by rename. The command prints `evidence_bundle` and
`evidence_bundle_sha256` for the release `status.json`. Set all live stage paths
to null when enabling those two fields. Portable and live modes cannot mix.
The release enables `artifacts/paper-evidence` with its receipt hash in `status.json`.

Keep the selected `example_candidate_id` in the portable paper configuration.
The copied selected source and verification reports reproduce that example;
the portable rebuild does not start a new Lean compilation.

The bundle layout is:

- `bundle.json`: byte inventory, original-to-portable input map, full hash
  inventory of inspected inputs, source-universe binding, and validation record.
- `records/`: verbatim reports, plans, manifests, calibration, all raw timing
  samples, census file outcomes, ledgers, snapshots, and setup metadata.
- `mathlib/`: originals for every manifest candidate file and every proposal
  whose source matches the pinned inventory, including rejected and overlapping
  proposals. This supports accounting and independent selection reanalysis.
- `census-archive/`: the compact archive's proposal and attempt history and
  validation sources. Some records already copied under `records/` are indexed
  there instead of duplicated. Raw events remain in the separate full archive.
- `project/`: frozen implementation and configuration for code-cost accounting.
- `verification-artifacts/`: one complete set of fresh proof-verification
  outputs. The bundle does not contain all timed-pass binaries.
- `tools/`: the validation, measurement, selection, and generation sources.
- `paper-inputs/`: the archived pilot data/source and the four-example source,
  successful Lean-check record, and compiled example object. Inputs already
  copied elsewhere are referenced rather than duplicated.

A portable rebuild verifies every copied byte, each proof-output hash, census
counts, patch accounting, and the full paired statistical result. Its validation
record states that runtime/import binaries were inspected at export; their
complete hashes remain in the bundle, but the dependency binaries need not be
copied. This is a recorded validation step, not a new runtime measurement or an
independent signature. The configured receipt hash binds the expected bundle.
There is no fallback to the original workspace when a copied input is missing.
The unit tests delete the original synthetic workspace before rebuilding from
the bundle and reject changed portable proof outputs. Portable mode checks the
published selector ledger and recomputes source accounting; it does not rerun
original elaboration, proof search, or the selector over the raw census events.

The paper can then regenerate the final tables from the portable bundle without
rerunning the timing experiment or opening the original absolute `.lake` paths.
To rebuild the PDF without Lean or a `.lake` directory, use:

```sh
python3 paper/build.py --reuse-checked-examples --render
```

This mode verifies the bundle's checked example source, object, and source hashes;
it does not claim a fresh Lean compilation. It also imports the archived pilot
block from the bundle, even if that block is absent from the final patch. The
ordinary build without this flag still recompiles all four examples using local
pinned Lean dependencies. The portable route needs the paper/repository sources,
validated bundle, and documented TeX/fonts/Poppler tools; it needs no original
absolute workspace paths and reruns no timing experiment. A new language review
and PDF layout review remain required
after real data enables the currently empty final-result tables.

Each build writes `paper/output/toolchain.json` with exact XeLaTeX, latexmk,
BibTeX, and pdfinfo version outputs. It hashes fonts identified by the log, file
recorder, and embedded PDF font names, plus explicit regular/bold/italic family
variants. Variant availability is labeled separately from actual use. Recorded
TeX class, package, and bibliography-style inputs and font warnings are retained
with their hashes. A read-only inspection record is labeled as such and does not
assert that a new PDF was built. No fonts are vendored.

The real font integration check uses the actual paper preamble, compiles all
regular/bold/italic/bold-italic serif, sans-serif, and monospace faces, and checks
the embedded PDF fonts. Run it with:

```sh
python3 -m unittest discover -s paper -p test_fonts.py
```

It skips only when XeLaTeX or pdffonts is unavailable. Its report is
`paper/output/font-integration.json`. The strict paper build also rejects font
substitution warnings. Font-family files are explicit in the preamble.
